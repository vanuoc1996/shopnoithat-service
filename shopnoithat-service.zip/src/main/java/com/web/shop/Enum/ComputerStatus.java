package com.web.shop.Enum;

public enum ComputerStatus {
    OFFLINE, ONLINE;
}
