package com.web.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopnoithatServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
